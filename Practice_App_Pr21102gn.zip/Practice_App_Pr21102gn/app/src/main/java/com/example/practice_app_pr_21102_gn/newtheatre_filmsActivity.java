package com.example.practice_app_pr_21102_gn;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class newtheatre_filmsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newtheatre_films);
    }
}